<?php

namespace App\Service;

class Converter {

    public function ConvertRubToUsd($Rub) {
        return $Rub/60;
    }
}
