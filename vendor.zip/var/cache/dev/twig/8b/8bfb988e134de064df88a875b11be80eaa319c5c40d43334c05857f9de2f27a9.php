<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* client/user.html.twig */
class __TwigTemplate_3e56282feecab79e8eaa9bf0dbc5837559a1a61918eb75336d4a3beb04da61bf extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "client/user.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "client/user.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "client/user.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "autoccc.ru - Личный кабинет ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 3, $this->source); })()), "user", [], "any", false, false, false, 3), "username", [], "any", false, false, false, 3), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "<main class=\"main\">
    <div class=\"main__wrapper\">

        ";
        // line 9
        $this->loadTemplate("blocks/block-pageTitle.html.twig", "client/user.html.twig", 9)->display(twig_array_merge($context, ["text" => "Личный кабинет"]));
        // line 10
        echo "
        <div class=\"user\">

            <div class=\"user__infoContainer\">
                <div class=\"user__imgContainer\">
                    <img class=\"user__imgContainerImg\" src=\" ";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/catalogItem/06.jpg"), "html", null, true);
        echo " \" draggable=\"false\">
                </div>
                <ul class=\"user__infoContainerList\">
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">ID:</span>
                        <span class=\"user__text\">";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 20, $this->source); })()), "id", [], "any", false, false, false, 20), "html", null, true);
        echo "</span>
                    </li>
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">Имя:</span>
                        <span class=\"user__text\">";
        // line 24
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 24, $this->source); })()), "name", [], "any", false, false, false, 24), "html", null, true);
        echo "</span>
                    </li>
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">Дата регистрации:</span>
                        <span class=\"user__text\">";
        // line 28
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 28, $this->source); })()), "registerdate", [], "any", false, false, false, 28), "m.d.Y"), "html", null, true);
        echo "</span>
                    </li>
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">E-mail:</span>
                        <span class=\"user__text\">";
        // line 32
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 32, $this->source); })()), "email", [], "any", false, false, false, 32), "html", null, true);
        echo "</span>
                    </li>
                </ul>

                ";
        // line 36
        if (($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER") && 0 === twig_compare((isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 36, $this->source); })()), twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 36, $this->source); })()), "user", [], "any", false, false, false, 36)))) {
            // line 37
            echo "                <div class=\"userFasterInterface\">
                    <a href=\"/logout\">
                        <i class=\"userFasterInterface__button\">Выйти</i>
                    </a>
                </div>
                ";
        }
        // line 43
        echo "
            </div>
            
            <div class=\"user__auto\">

                <section class=\"user__autoTitleContainer\">

                    <h2 class=\"user__autoTitle\">Ваши объявления</h2>

                    <div class=\"userFasterInterface\">
                        <a href=\"/user/addauto\">
                            <i class=\"userFasterInterface__button\">Добавить объявление</i>
                        </a>
                    </div>

                </section>

                <div class=\"user__autolist\">
                ";
        // line 61
        if (0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 61, $this->source); })()), "catalogAutos", [], "any", false, false, false, 61), "isEmpty", [], "any", false, false, false, 61), false)) {
            // line 62
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 62, $this->source); })()), "getNoDeletedCatalogAutos", [], "any", false, false, false, 62));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["auto"]) {
                // line 63
                echo "                    ";
                $this->loadTemplate("blocks/block-catalogItem.html.twig", "client/user.html.twig", 63)->display(twig_array_merge($context, ["auto" => $context["auto"]]));
                // line 64
                echo "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['auto'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 65
            echo "                ";
        }
        // line 66
        echo "                </div>
            </div>

        </div>

    </div>
</main>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "client/user.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  209 => 66,  206 => 65,  192 => 64,  189 => 63,  171 => 62,  169 => 61,  149 => 43,  141 => 37,  139 => 36,  132 => 32,  125 => 28,  118 => 24,  111 => 20,  103 => 15,  96 => 10,  94 => 9,  89 => 6,  79 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}autoccc.ru - Личный кабинет {{ app.user.username }}{% endblock %}

{% block main %}
<main class=\"main\">
    <div class=\"main__wrapper\">

        {% include('blocks/block-pageTitle.html.twig') with {'text' : 'Личный кабинет'} %}

        <div class=\"user\">

            <div class=\"user__infoContainer\">
                <div class=\"user__imgContainer\">
                    <img class=\"user__imgContainerImg\" src=\" {{ asset('img/catalogItem/06.jpg') }} \" draggable=\"false\">
                </div>
                <ul class=\"user__infoContainerList\">
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">ID:</span>
                        <span class=\"user__text\">{{ user.id }}</span>
                    </li>
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">Имя:</span>
                        <span class=\"user__text\">{{ user.name }}</span>
                    </li>
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">Дата регистрации:</span>
                        <span class=\"user__text\">{{ user.registerdate|date(\"m.d.Y\") }}</span>
                    </li>
                    <li class=\"user__infoContainerListItem\">
                        <span class=\"user__nameLabel\">E-mail:</span>
                        <span class=\"user__text\">{{ user.email }}</span>
                    </li>
                </ul>

                {% if is_granted('ROLE_USER') and (user == app.user)  %}
                <div class=\"userFasterInterface\">
                    <a href=\"/logout\">
                        <i class=\"userFasterInterface__button\">Выйти</i>
                    </a>
                </div>
                {% endif %}

            </div>
            
            <div class=\"user__auto\">

                <section class=\"user__autoTitleContainer\">

                    <h2 class=\"user__autoTitle\">Ваши объявления</h2>

                    <div class=\"userFasterInterface\">
                        <a href=\"/user/addauto\">
                            <i class=\"userFasterInterface__button\">Добавить объявление</i>
                        </a>
                    </div>

                </section>

                <div class=\"user__autolist\">
                {% if user.catalogAutos.isEmpty == false %}
                {% for auto  in user.getNoDeletedCatalogAutos  %}
                    {% include('blocks/block-catalogItem.html.twig') with {'auto' : auto} %}
                {% endfor %}
                {% endif %}
                </div>
            </div>

        </div>

    </div>
</main>
{% endblock %}", "client/user.html.twig", "D:\\OSPanel\\domains\\my-project\\templates\\client\\user.html.twig");
    }
}
