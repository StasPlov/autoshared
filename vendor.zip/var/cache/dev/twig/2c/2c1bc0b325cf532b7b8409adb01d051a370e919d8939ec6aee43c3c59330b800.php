<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blocks/block-menu.html.twig */
class __TwigTemplate_3d88a77d483b0c453ed94ceba70e4593263fc77900d512d0aa87e2a7253e016c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blocks/block-menu.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blocks/block-menu.html.twig"));

        // line 1
        echo "<nav class=\"menu\">
    <ul class=\"menuList \">

        <li class=\"menuList__item\">
            <a href=\"/catalog\" class=\"menuList__link\">Каталог</a>
        </li>
        
        ";
        // line 8
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER")) {
            // line 9
            echo "        <li class=\"menuList__item\">
            <a href=\"/user\" class=\"menuList__link\">Личный кабинет</a>
        </li>

        ";
            // line 13
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
                // line 14
                echo "        <li class=\"menuList__item\">
            <a href=\"/admin\" class=\"menuList__link\">Админ панель</a>
        </li>
        ";
            }
            // line 18
            echo "
        ";
        } else {
            // line 20
            echo "        <li class=\"menuList__item\">
            <a href=\"/login\" class=\"menuList__link\">Войти</a>
        </li>
        ";
        }
        // line 24
        echo "
    </ul>

    <div id=\"open-mobile-menu\" class=\"globalMobile__openMobileMenuButton globalMobileContent\">☰</div>
    
    <div id=\"mobile-menu\" class=\"globalMobileMenu globalMobileContent animated fadeOut hide\">
        <ul class=\"globalMobile__container\">
            <li class=\"globalMobile__containerItem\">
                <a href=\"/catalog\" class=\"menuList__link\">Каталог</a>
            </li>
            
            ";
        // line 35
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER")) {
            // line 36
            echo "            <li class=\"globalMobile__containerItem\">
                <a href=\"/user\" class=\"menuList__link\">Личный кабинет</a>
            </li>

            ";
            // line 40
            if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
                // line 41
                echo "            <li class=\"globalMobile__containerItem\">
                <a href=\"/admin\" class=\"menuList__link\">Админ панель</a>
            </li>
            ";
            }
            // line 45
            echo "
            ";
        } else {
            // line 47
            echo "            <li class=\"globalMobile__containerItem\">
                <a href=\"/login\" class=\"menuList__link\">Войти</a>
            </li>
            ";
        }
        // line 51
        echo "
        </ul>
        <i id=\"close-mobile-menu\" class=\"globalMobile__closeMobileMenu\">×</i>
    </div>
</nav>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blocks/block-menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 51,  111 => 47,  107 => 45,  101 => 41,  99 => 40,  93 => 36,  91 => 35,  78 => 24,  72 => 20,  68 => 18,  62 => 14,  60 => 13,  54 => 9,  52 => 8,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<nav class=\"menu\">
    <ul class=\"menuList \">

        <li class=\"menuList__item\">
            <a href=\"/catalog\" class=\"menuList__link\">Каталог</a>
        </li>
        
        {% if is_granted('ROLE_USER') %}
        <li class=\"menuList__item\">
            <a href=\"/user\" class=\"menuList__link\">Личный кабинет</a>
        </li>

        {% if is_granted('ROLE_ADMIN') %}
        <li class=\"menuList__item\">
            <a href=\"/admin\" class=\"menuList__link\">Админ панель</a>
        </li>
        {% endif %}

        {% else %}
        <li class=\"menuList__item\">
            <a href=\"/login\" class=\"menuList__link\">Войти</a>
        </li>
        {% endif %}

    </ul>

    <div id=\"open-mobile-menu\" class=\"globalMobile__openMobileMenuButton globalMobileContent\">☰</div>
    
    <div id=\"mobile-menu\" class=\"globalMobileMenu globalMobileContent animated fadeOut hide\">
        <ul class=\"globalMobile__container\">
            <li class=\"globalMobile__containerItem\">
                <a href=\"/catalog\" class=\"menuList__link\">Каталог</a>
            </li>
            
            {% if is_granted('ROLE_USER') %}
            <li class=\"globalMobile__containerItem\">
                <a href=\"/user\" class=\"menuList__link\">Личный кабинет</a>
            </li>

            {% if is_granted('ROLE_ADMIN') %}
            <li class=\"globalMobile__containerItem\">
                <a href=\"/admin\" class=\"menuList__link\">Админ панель</a>
            </li>
            {% endif %}

            {% else %}
            <li class=\"globalMobile__containerItem\">
                <a href=\"/login\" class=\"menuList__link\">Войти</a>
            </li>
            {% endif %}

        </ul>
        <i id=\"close-mobile-menu\" class=\"globalMobile__closeMobileMenu\">×</i>
    </div>
</nav>", "blocks/block-menu.html.twig", "D:\\OSPanel\\domains\\my-project\\templates\\blocks\\block-menu.html.twig");
    }
}
