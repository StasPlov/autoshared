<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* admin/index.html.twig */
class __TwigTemplate_b21162ac8c143171a3d7256bbf36c29b9e328d3e688e7163eba7816262cdfa88 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "admin/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "admin/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "autoccc.ru - Админ панель";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "<main class=\"main\">
    <div class=\"main__wrapper\">

        <div class=\"main__interface\">

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\01.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Навигация</h2>
                    <span class=\"catalogItem__text\">Настройки панелей, разделов меню сайта</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\02.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Файлы</h2>
                    <span class=\"catalogItem__text\">Представляет возможности загрузки различных файлов</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\03.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Настройки пользователей</h2>
                    <span class=\"catalogItem__text\">Какой-то текст с описанием этого блока</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\04.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Статистика</h2>
                    <span class=\"catalogItem__text\">Просмотр статистики, посещеных страниц, файлов логирования, а так же информации о версии движка.</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\08.png\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Магазин</h2>
                    <span class=\"catalogItem__text\">Настройка сисемы магазина вашего сата</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\06.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Настройки пользователей</h2>
                    <span class=\"catalogItem__text\">Какой-то текст с описанием этого блока</span>
                </div>
            </section>

        </div>

    </div>
</main>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "admin/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}autoccc.ru - Админ панель{% endblock %}

{% block main %}
<main class=\"main\">
    <div class=\"main__wrapper\">

        <div class=\"main__interface\">

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\01.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Навигация</h2>
                    <span class=\"catalogItem__text\">Настройки панелей, разделов меню сайта</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\02.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Файлы</h2>
                    <span class=\"catalogItem__text\">Представляет возможности загрузки различных файлов</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\03.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Настройки пользователей</h2>
                    <span class=\"catalogItem__text\">Какой-то текст с описанием этого блока</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\04.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Статистика</h2>
                    <span class=\"catalogItem__text\">Просмотр статистики, посещеных страниц, файлов логирования, а так же информации о версии движка.</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\08.png\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Магазин</h2>
                    <span class=\"catalogItem__text\">Настройка сисемы магазина вашего сата</span>
                </div>
            </section>

            <section class=\"catalogItem\">
                <div class=\"catalogItem__imgContainer\">
                    <img class=\"catalogItem__img\" src=\"img\\catalogItem\\06.jpg\" draggable=\"false\">
                </div>
                <div class=\"catalogItem__aboutContainer\">
                    <h2 class=\"catalogItem__header\">Настройки пользователей</h2>
                    <span class=\"catalogItem__text\">Какой-то текст с описанием этого блока</span>
                </div>
            </section>

        </div>

    </div>
</main>
{% endblock %}", "admin/index.html.twig", "D:\\OSPanel\\domains\\my-project\\templates\\admin\\index.html.twig");
    }
}
