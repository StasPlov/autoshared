<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* client/auto.html.twig */
class __TwigTemplate_a2f8dfbf12bcfefcd86399bd808d568f8bc4aa53a70a23ed95f5d57327bfffbb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "client/auto.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "client/auto.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "client/auto.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "autoccc.ru - ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 3, $this->source); })()), "mark", [], "any", false, false, false, 3), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 3, $this->source); })()), "model", [], "any", false, false, false, 3), "html", null, true);
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_main($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "main"));

        // line 7
        echo "
    <main class=\"main\">
        <div class=\"main__wrapper\">

            <div class=\"catalogItemDetailed\">

                <section class=\"catalogItemDetailed__TitleContainer\">
                    <h2 class=\"catalogItemDetailed__title\">";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 14, $this->source); })()), "mark", [], "any", false, false, false, 14), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 14, $this->source); })()), "model", [], "any", false, false, false, 14), "html", null, true);
        echo "</h2>

                    ";
        // line 16
        if (($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER") && 0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 16, $this->source); })()), "user", [], "any", false, false, false, 16), twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "user", [], "any", false, false, false, 16)))) {
            // line 17
            echo "                    <div class=\"userFasterInterface\">
                        <a href=\"/user/editauto/";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 18, $this->source); })()), "id", [], "any", false, false, false, 18), "html", null, true);
            echo "\">
                            <i class=\"userFasterInterface__button\">Редактировать</i>
                        </a>
                        <a href=\"/user/deleteauto/";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 21, $this->source); })()), "id", [], "any", false, false, false, 21), "html", null, true);
            echo "\">
                            <i class=\"userFasterInterface__button\">Удалить</i>
                        </a>
                    </div>
                    ";
        }
        // line 26
        echo "                </section>

                <div id=\"gallery-items\">
                    <div class=\"catalogItemDetailed__imgContainer\">
                        <img class=\"catalogItemDetailed__img\" src=\" ";
        // line 30
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/catalogItem/06.jpg"), "html", null, true);
        echo " \" draggable=\"false\">
                    </div>
                </div>

                <div class=\"catalogItemDetailed__aboutContainer\">

                    <ul class=\"autoInformationList\">

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Двигатель: </span>
                            <span class=\"autoInformationList__itemText\">";
        // line 40
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 40, $this->source); })()), "engine", [], "any", false, false, false, 40), "html", null, true);
        echo "</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Мощность: </span>
                            <span class=\"autoInformationList__itemText\">";
        // line 45
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 45, $this->source); })()), "power", [], "any", false, false, false, 45), "html", null, true);
        echo "</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Трансмиссия: </span>
                            <span class=\"autoInformationList__itemText\">";
        // line 50
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 50, $this->source); })()), "transmission", [], "any", false, false, false, 50), "html", null, true);
        echo "</span>
                        </li>

                                
                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Привод: </span>
                            <span class=\"autoInformationList__itemText\">";
        // line 56
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 56, $this->source); })()), "drive", [], "any", false, false, false, 56), "html", null, true);
        echo "</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Цвет: </span>
                            <span class=\"autoInformationList__itemText\">";
        // line 61
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 61, $this->source); })()), "color", [], "any", false, false, false, 61), "html", null, true);
        echo "</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Пробег, км:</span>
                            <span class=\"autoInformationList__itemText\">";
        // line 66
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 66, $this->source); })()), "mileage", [], "any", false, false, false, 66), "html", null, true);
        echo "</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Руль: </span>
                            <span class=\"autoInformationList__itemText\">";
        // line 71
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 71, $this->source); })()), "steering", [], "any", false, false, false, 71), "html", null, true);
        echo "</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Номер кузова: </span>
                            <span class=\"autoInformationList__itemText\">";
        // line 76
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 76, $this->source); })()), "bodynumber", [], "any", false, false, false, 76), "html", null, true);
        echo "</span>
                        </li>

                    </ul>

                    <span class=\"catalogItemDetailed__text\">";
        // line 81
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 81, $this->source); })()), "description", [], "any", false, false, false, 81), "html", null, true);
        echo "</span>
                    
                    ";
        // line 83
        if (0 === twig_compare(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 83, $this->source); })()), "comments", [], "any", false, false, false, 83), "isEmpty", [], "any", false, false, false, 83), false)) {
            // line 84
            echo "                    <div class=\"catalogItemDetailed__comments\">
                        ";
            // line 85
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 85, $this->source); })()), "NoDeletedComments", [], "any", false, false, false, 85));
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 86
                echo "                        <section class=\"comment\">

                            <span class=\"comment__text\">";
                // line 88
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "content", [], "any", false, false, false, 88), "html", null, true);
                echo "</span>

                            ";
                // line 91
                echo "                            ";
                if ((($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER") && 0 === twig_compare(twig_get_attribute($this->env, $this->source, $context["comment"], "user", [], "any", false, false, false, 91), twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 91, $this->source); })()), "user", [], "any", false, false, false, 91))) && 0 !== twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 91, $this->source); })()), "user", [], "any", false, false, false, 91), twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 91, $this->source); })()), "user", [], "any", false, false, false, 91)))) {
                    // line 92
                    echo "                            <div class=\"userFasterInterface\">
                                <a href=\"/catalog/";
                    // line 93
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 93, $this->source); })()), "id", [], "any", false, false, false, 93), "html", null, true);
                    echo "/commentedit/";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 93), "html", null, true);
                    echo "\">
                                    <i class=\"userFasterInterface__button\">Редактировать</i>
                                </a>
                                <a href=\"/catalog/";
                    // line 96
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 96, $this->source); })()), "id", [], "any", false, false, false, 96), "html", null, true);
                    echo "/commentdelete/";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 96), "html", null, true);
                    echo "\">
                                    <i class=\"userFasterInterface__button\">Удалить</i>
                                </a>
                            </div>
                            ";
                    // line 101
                    echo "                            ";
                } elseif (($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER") && 0 === twig_compare(twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 101, $this->source); })()), "user", [], "any", false, false, false, 101), twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 101, $this->source); })()), "user", [], "any", false, false, false, 101)))) {
                    // line 102
                    echo "                            <div class=\"userFasterInterface\">
                                <a href=\"/catalog/";
                    // line 103
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 103, $this->source); })()), "id", [], "any", false, false, false, 103), "html", null, true);
                    echo "/commentedit/";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 103), "html", null, true);
                    echo "\">
                                    <i class=\"userFasterInterface__button\">Редактировать</i>
                                </a>
                                <a href=\"/catalog/";
                    // line 106
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 106, $this->source); })()), "id", [], "any", false, false, false, 106), "html", null, true);
                    echo "/commentdelete/";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 106), "html", null, true);
                    echo "\">
                                    <i class=\"userFasterInterface__button\">Удалить</i>
                                </a>
                            </div>
                            ";
                }
                // line 111
                echo "
                        </section>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 114
            echo "                    </div>
                    ";
        }
        // line 116
        echo "
                    ";
        // line 117
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_USER")) {
            // line 118
            echo "                        ";
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 118, $this->source); })()), 'form_start', ["attr" => ["class" => "addCommentForm"]]);
            echo "
                            ";
            // line 119
            echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 119, $this->source); })()), 'widget', ["attr" => ["class" => "addCommentForm__container"]]);
            echo "
                        ";
            // line 120
            echo             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["commentForm"]) || array_key_exists("commentForm", $context) ? $context["commentForm"] : (function () { throw new RuntimeError('Variable "commentForm" does not exist.', 120, $this->source); })()), 'form_end');
            echo "
                    ";
        }
        // line 122
        echo "
                </div>              
                    
            </div>

        </div>
    </main>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "client/auto.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  311 => 122,  306 => 120,  302 => 119,  297 => 118,  295 => 117,  292 => 116,  288 => 114,  280 => 111,  270 => 106,  262 => 103,  259 => 102,  256 => 101,  247 => 96,  239 => 93,  236 => 92,  233 => 91,  228 => 88,  224 => 86,  220 => 85,  217 => 84,  215 => 83,  210 => 81,  202 => 76,  194 => 71,  186 => 66,  178 => 61,  170 => 56,  161 => 50,  153 => 45,  145 => 40,  132 => 30,  126 => 26,  118 => 21,  112 => 18,  109 => 17,  107 => 16,  100 => 14,  91 => 7,  81 => 6,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}autoccc.ru - {{ auto.mark }} {{ auto.model }}{% endblock %}


{% block main %}

    <main class=\"main\">
        <div class=\"main__wrapper\">

            <div class=\"catalogItemDetailed\">

                <section class=\"catalogItemDetailed__TitleContainer\">
                    <h2 class=\"catalogItemDetailed__title\">{{ auto.mark }} {{ auto.model }}</h2>

                    {% if is_granted('ROLE_USER') and (auto.user == app.user)  %}
                    <div class=\"userFasterInterface\">
                        <a href=\"/user/editauto/{{ auto.id }}\">
                            <i class=\"userFasterInterface__button\">Редактировать</i>
                        </a>
                        <a href=\"/user/deleteauto/{{ auto.id }}\">
                            <i class=\"userFasterInterface__button\">Удалить</i>
                        </a>
                    </div>
                    {% endif %}
                </section>

                <div id=\"gallery-items\">
                    <div class=\"catalogItemDetailed__imgContainer\">
                        <img class=\"catalogItemDetailed__img\" src=\" {{ asset('img/catalogItem/06.jpg') }} \" draggable=\"false\">
                    </div>
                </div>

                <div class=\"catalogItemDetailed__aboutContainer\">

                    <ul class=\"autoInformationList\">

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Двигатель: </span>
                            <span class=\"autoInformationList__itemText\">{{ auto.engine }}</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Мощность: </span>
                            <span class=\"autoInformationList__itemText\">{{ auto.power }}</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Трансмиссия: </span>
                            <span class=\"autoInformationList__itemText\">{{ auto.transmission }}</span>
                        </li>

                                
                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Привод: </span>
                            <span class=\"autoInformationList__itemText\">{{ auto.drive }}</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Цвет: </span>
                            <span class=\"autoInformationList__itemText\">{{ auto.color }}</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Пробег, км:</span>
                            <span class=\"autoInformationList__itemText\">{{ auto.mileage }}</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Руль: </span>
                            <span class=\"autoInformationList__itemText\">{{ auto.steering }}</span>
                        </li>

                        <li class=\"autoInformationList__item\">
                            <span class=\"autoInformationList__itemHeader\">Номер кузова: </span>
                            <span class=\"autoInformationList__itemText\">{{ auto.bodynumber }}</span>
                        </li>

                    </ul>

                    <span class=\"catalogItemDetailed__text\">{{ auto.description }}</span>
                    
                    {% if auto.comments.isEmpty == false %}
                    <div class=\"catalogItemDetailed__comments\">
                        {% for comment  in auto.NoDeletedComments  %}
                        <section class=\"comment\">

                            <span class=\"comment__text\">{{ comment.content }}</span>

                            {# Если мы авторизированые и это мой комментарий, но не мое объявление, то я могу удалять только свой комментарий #}
                            {% if is_granted('ROLE_USER') and (comment.user == app.user) and (auto.user != app.user)  %}
                            <div class=\"userFasterInterface\">
                                <a href=\"/catalog/{{ auto.id }}/commentedit/{{ comment.id }}\">
                                    <i class=\"userFasterInterface__button\">Редактировать</i>
                                </a>
                                <a href=\"/catalog/{{ auto.id }}/commentdelete/{{ comment.id }}\">
                                    <i class=\"userFasterInterface__button\">Удалить</i>
                                </a>
                            </div>
                            {# Если мы авторизированые и это мой комсентарий, и мое объявление, то я могу удалять все комментарии #}
                            {% elseif is_granted('ROLE_USER') and (auto.user == app.user) %}
                            <div class=\"userFasterInterface\">
                                <a href=\"/catalog/{{ auto.id }}/commentedit/{{ comment.id }}\">
                                    <i class=\"userFasterInterface__button\">Редактировать</i>
                                </a>
                                <a href=\"/catalog/{{ auto.id }}/commentdelete/{{ comment.id }}\">
                                    <i class=\"userFasterInterface__button\">Удалить</i>
                                </a>
                            </div>
                            {% endif %}

                        </section>
                        {% endfor %}
                    </div>
                    {% endif %}

                    {% if is_granted('ROLE_USER') %}
                        {{ form_start(commentForm, {'attr' : {'class' : 'addCommentForm'}}) }}
                            {{ form_widget(commentForm, {'attr' : {'class' : 'addCommentForm__container'}}) }}
                        {{ form_end(commentForm) }}
                    {% endif %}

                </div>              
                    
            </div>

        </div>
    </main>

{% endblock %}", "client/auto.html.twig", "D:\\OSPanel\\domains\\my-project\\templates\\client\\auto.html.twig");
    }
}
