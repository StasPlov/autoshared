<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blocks/block-catalogItem.html.twig */
class __TwigTemplate_6a1412a0692319ef6e22913902d8da0133a036601759e18631692881fee7bc93 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blocks/block-catalogItem.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blocks/block-catalogItem.html.twig"));

        // line 1
        echo "<a href=\"/catalog/";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 1, $this->source); })()), "id", [], "any", false, false, false, 1), "html", null, true);
        echo "\" class=\"catalogItem\">

    <div class=\"catalogItem__imgContainer\">
        <img class=\"catalogItem__img\" src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/catalogItem/01.jpg"), "html", null, true);
        echo "\" draggable=\"false\">
    </div>

    <div class=\"catalogItem__aboutContainer\">
    
        <h2 class=\"catalogItem__header\">";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 9, $this->source); })()), "mark", [], "any", false, false, false, 9), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 9, $this->source); })()), "model", [], "any", false, false, false, 9), "html", null, true);
        echo "</h2>
    
        <ul class=\"autoInformationList\">

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Двигатель: </span>
                <span class=\"autoInformationList__itemText\">";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 15, $this->source); })()), "engine", [], "any", false, false, false, 15), "html", null, true);
        echo "</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Мощность: </span>
                <span class=\"autoInformationList__itemText\">";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 20, $this->source); })()), "power", [], "any", false, false, false, 20), "html", null, true);
        echo "</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Трансмиссия: </span>
                <span class=\"autoInformationList__itemText\">";
        // line 25
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 25, $this->source); })()), "drive", [], "any", false, false, false, 25), "html", null, true);
        echo "</span>
            </li>
            
            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Привод: </span>
                <span class=\"autoInformationList__itemText\">";
        // line 30
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 30, $this->source); })()), "transmission", [], "any", false, false, false, 30), "html", null, true);
        echo "</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Цвет: </span>
                <span class=\"autoInformationList__itemText\">";
        // line 35
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 35, $this->source); })()), "color", [], "any", false, false, false, 35), "html", null, true);
        echo "</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Пробег, км:</span>
                <span class=\"autoInformationList__itemText\">";
        // line 40
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 40, $this->source); })()), "mileage", [], "any", false, false, false, 40), "html", null, true);
        echo "</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Руль: </span>
                <span class=\"autoInformationList__itemText\">";
        // line 45
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 45, $this->source); })()), "steering", [], "any", false, false, false, 45), "html", null, true);
        echo "</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Номер кузова: </span>
                <span class=\"autoInformationList__itemText\">";
        // line 50
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["auto"]) || array_key_exists("auto", $context) ? $context["auto"] : (function () { throw new RuntimeError('Variable "auto" does not exist.', 50, $this->source); })()), "bodyNumber", [], "any", false, false, false, 50), "html", null, true);
        echo "</span>
            </li>

        </ul>

    </div>
</a>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blocks/block-catalogItem.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 50,  117 => 45,  109 => 40,  101 => 35,  93 => 30,  85 => 25,  77 => 20,  69 => 15,  58 => 9,  50 => 4,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<a href=\"/catalog/{{ auto.id }}\" class=\"catalogItem\">

    <div class=\"catalogItem__imgContainer\">
        <img class=\"catalogItem__img\" src=\"{{ asset('img/catalogItem/01.jpg') }}\" draggable=\"false\">
    </div>

    <div class=\"catalogItem__aboutContainer\">
    
        <h2 class=\"catalogItem__header\">{{ auto.mark }} {{ auto.model }}</h2>
    
        <ul class=\"autoInformationList\">

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Двигатель: </span>
                <span class=\"autoInformationList__itemText\">{{ auto.engine }}</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Мощность: </span>
                <span class=\"autoInformationList__itemText\">{{ auto.power }}</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Трансмиссия: </span>
                <span class=\"autoInformationList__itemText\">{{ auto.drive }}</span>
            </li>
            
            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Привод: </span>
                <span class=\"autoInformationList__itemText\">{{ auto.transmission }}</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Цвет: </span>
                <span class=\"autoInformationList__itemText\">{{ auto.color }}</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Пробег, км:</span>
                <span class=\"autoInformationList__itemText\">{{ auto.mileage }}</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Руль: </span>
                <span class=\"autoInformationList__itemText\">{{ auto.steering }}</span>
            </li>

            <li class=\"autoInformationList__item\">
                <span class=\"autoInformationList__itemHeader\">Номер кузова: </span>
                <span class=\"autoInformationList__itemText\">{{ auto.bodyNumber }}</span>
            </li>

        </ul>

    </div>
</a>", "blocks/block-catalogItem.html.twig", "D:\\OSPanel\\domains\\my-project\\templates\\blocks\\block-catalogItem.html.twig");
    }
}
